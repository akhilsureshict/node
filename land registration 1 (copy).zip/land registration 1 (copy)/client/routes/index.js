var express = require('express');
var router = express.Router();
var {Property} = require('./UserClient')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('dashboards', { title: 'Dashboards' });
});
router.get('/Propertylist',async(req,res)=>{
  var propertyClient =new Property();
  let stateData =await propertyClient.getPropertyClient.getPropertyListings();
  let propertyList =[];
  stateData.data.forEach(properties=>{
    if(!properties.data) return;
    let decodedProperties =Buffer.from(properties.data,'base64').ioString();
    let propertyDetails = decodedProperties.split(',');

    propertyList.push({
      OwnNam: propertyDetails[4],
      Aadno : propertyDetails[4],
      LArea: propertyDetails[3],
      adrs:propertyDetails[9],
      status:(propertyDetails.length === 5)?"Not Registered":"Registered",
      doa: propertyDetails[2],
      adrs:propertyDetails[9],
      dor:propertyDetails[2],
      sur:propertyDetails[3]
      
    });
  
});
res.render('propertyList',{listings: propertyList})
});

router.get('/homePage',(res,res)=>{
    res.render('dashboards',{title:'Dashboards'});

});

router.post('/addProperty',function(req,res){
  let key= req.body.key
  let own=req.body.own
  let aad=req.body.aad
  let lan=req.body.lan
  let da =req.body.date  
  let add=req.body.add
  let mob=req.body.mob
  let nom=req.body.nom
  let nad=req.body.nad
  console.log("Data sent to REST API");
  var client = new property();
  client.addProperty("Application",key,own,lan,aad,da,add,mob,nom,nad)
  res.send({message:"Data successfully added"});
  
  

})
router.post('/registerProperty',function(req,res){
  let key= req.body.key
  let Ownname=req.body.Ownname
  let Ownaad=req.body.Ownaad
  let larea=req.body.larea
  let dr=req.body.date
  let adrs=req.body.adrs
  let mobi=req.body.mobi
  let nomi=req.body.nomi
  let nomiaad=req.body.nomiaad
  console.log("Datasent to REST API");
  var client= new Property();
  client.registerProperty("Registrar",key,Ownname,ownaad,larea,da,adrs,mobi,nomi,nomiaad)
  res.send({message:"Data succesfully added"});


})
module.exports = router;
