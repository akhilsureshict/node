const {TextDecoder,TextEncoder} = require('text-encoding/lib/encoding')
const {TransactionHandler} = require('sawtooth-sdk/processor/handler')
const {TransactionProcessor} = require('sawtooth-sdk/processor');
const crypto =require('crypto');
const {Secp256k1PrivateKey} =require('sawtooth-sdk/signing/secp256k1')
const {createContext,CryptoFactory} = require('sawtooth-sdk/signing');
 
const FAMILY_NAME = "Property Chain"
const NAMESPACE = hash(FAMILY_NAME).substring(0,6);
var decoder =new TextDecoder('utf8')
var encoder =new TextEncoder('utf8')
APPLICATIONKEY = '8f99bb8b1dc799fd1ed9b7e370330f9378c78f7c332ac3e2233bf559ce21ea8b'

function hash(data) {
    return crypto.createHash("sha512").update(data).digest('hex');
}
/* function to write data to state
parameter:
context -validdator context object
address- address to which data should be written to
data- the data to be written */
function writeToStore(context,address,data){
    dataBytes =encoder.encode(data)
    let entries ={
        [address]: databytes
    }
    return context.setState(entries);

}
/* function to retrieve the address of a particular property based on its aadharn0*/

function getPropertyAddress(Aadnum){
    const context = createContext('secp256k1');
    let key =Secp256k1PrivateKey.fromHex(APPLICATIONKEY)
    let signer =new CryptoFactory(context).newSigner(key);
    let publicKeyHex =signer.getPublicKey().asHex()
    let keyHash =hash(publicKeyHex)
    let nameHash =hash("Property Chain")
    let AadHash =hash(AadNum)
    return nameHash.slice(0,6) +AadHash.slice(0,6)+keyHash.slice(0,58)    
}
function getPropertyDataAddress(){
    const context = createContext('secp256k1');
    let key =Secp2561Private.fromHex(APPLICATIONKEY)
    let signer =new CryptoFactory(context).newSigner(key);
    let publicKeyHex =signer.getPublicKey().asHex()
    let keyHash =hash(publicKeyHex)
    let nameHash =hash("Property Chain")
    let AadHash =hash(AadNum)
    return nameHash.slice(0,6) + AadHash.slice(0,6)+keyHash.slice(0,58)

}
/* function to add new property to chain
parameter:
context-validator context object
OwnNam-name of the owner
Aadnum -aadhar number of owner
LArea -land area to be registered
doa -date of application
Addrs-Address of owner
MobNum-mobile number of owner
NomNam-nominee name
Nomaad-nominee aadhar number*/
function addProperty(context,OwnNam,AadNum,LArea,doa,Addrs,MobNum,NomNam,Nomaad){
    let property_Address = getPropertyAddress(AadNum)
    let property_detail =[OwnNam,AadNum,LArea,doa,Addrs,MobNum,NomNam,Nomaad]
    return writeToStore(context,property_Address,property_detail)
}

/* function to add register details of the property added
        Ownnam -name of owner
        registerkey-key for registration
        Aadno-aadhar no of owner
        adrs-owner address
        dor-date of registration
        dist-district where property is located
        sur-survey number*/

function registerProperty(context,Ownnam,Aadno,adrs,dor,dist,sur){
    console.log("registering property")
    let address =getPropertyAddress(Aadno)
    return context.getState([address]).then(function(data){
        console.log("data",data)
        if(data[address] == null  ||data[address] == "" || data[address] ==[]){
            console.log("Invalid Aadhar number!")
        }else{
            let stateJSON =decoder.decode(data[address])
            let newData = stateJSON + "," +[dor,Ownnam,Aadno,adrs,dist,sur].join(',')
            return writeToStore(context,address,newData)
        }
        
    })
}
// transaction handler class
class Property extends TransactionHandler{
    constructor(){
        super(FAMILY_NAME, ['1.0'], [NAMESPACE]);

    }
//apply function
    apply(transactionProcessRequest, context){
        let PayloadBytes = decoder.decode(transactionProcessRequest.payload)
        let Payload = PayloadBytes.toString().split(',')
        let action =Payload[0]
        if (action === "Add Property"){
            return addProperty(context,Payload[1],Payload[2],Payload[3],Payload[4],Payload[5],Payload[6],Payload[7],Payload[8])
        }else if(action ==="Register Property"){
            return registerProperty(context,Payload[1],Payload[2],payload[3],payload[4],payload[5],payload[6],payload[7],payload[8])
        }

    }
}
module.exports = Property;