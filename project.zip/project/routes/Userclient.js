const fetch = require('node-fetch');
const crypto = require('crypto');
const {CryptoFactory, createContext} =require('sawtooth-sdk/signing')
const protobuf =require('sawtooth-sdk/protobuf')
const {Secp2561PrivateKey} =require('sawtooth-sdk/signing/secp256k1')
const {TextEncoder} =require('text-encoding/lib/encoding')
var encoder =new TextEncoder('utf8');

APPLICATIONKEY = '8f99bb8b1dc799fd1ed9b7e370330f9378c78f7c332ac3e2233bf559ce21ea8b'
REGISTERATIONKEY = '4206848f09f0953370fc3e4a131faeab07e239d451190294e5049cfcf05a107e'

FAMILY_NAME = 'Property Chain'

function hash(data) {
    return crypto.createHash('sha512').update(data).digest('hex');

}
function getPropertyAddress(AadNum){
    const context = createContext('secp256k1');
    let key = Secp2561PrivateKey.fromHex(APPLICATIONKEY)
    let signer = new CryptoFactory(context).newSigner(key);
    let publicKeyHex =signer.getPublicKey().asHex()
    let KeyHash = hash(getPublicKey)
    let nameHash = hash("Property Chain")
    let Aadhash =hash(AadNum)
    return nameHash.slice(0,6) +AadHash.slice(0,6)+KeyHash.slice(0,58)

}
/* function to create transaction
familyName - the transaction family name
inputlist -list of input address
outputlist -list of output address
privkey- the userpublickey
payload -payload
familyVersion -the version of the family*/

function createTransaction(familyName,inputList,outputList,Privkey,payload,familyVersion ='1.0'){
    const privateKeyHex = Privkey
    const context =createContext('secp256k1');
    const secp256k1pk =Secp256k1PrivateKey.fromHex(privateKeyHex.trim());
    signer =new CryptoFactory(context).newSigner(secp256k1pk);
    const payloadBytes =encode.encode(payload)
    //create transaction header
    const transactionHeaderBytes =protobuf.TransactionHeader.encode({
        familyName:familyName,
        familyVersion:familyVersion,
        inputs: inputList,
        outputs:outputList,
        signerPublicKey:signer.getPublicKey().asHex(),
        nonce: "" + Math.random(),
        batcherPublicKey: signer.getPublicKey().asHex(),
        dependencies:[],
        payloadSha512: hash(payloadBytes),
    }).finish();
    //create transaction
    const transaction = protobuf.Transaction.create({
        header:transactionHeaderBytes,
        headerSignature:signer.sign(transactionHeaderBytes),
        payload: payloadBytes

    });
    const transctions =[transaction];
    //create batch header
    const batchHeaderBytes =protobuf.BatchHeader.encode({
    signerPublicKey:signer.getPublicKey().asHex(),
    transactionIds:transactions.map((txn) => txn.headerSignature),    
    }).finish();
    //createbatch
    const batch = protobuf.Batch.create({
        header:batchHeaderBytes,
        headerSignature: batchSignature,
        transactions: transactions,
    });
    //create batchlist
    const batchListBytes = protobuf.BatchList.encode({
        batches: [batch]
    }).finish();
    sendTransaction(batchListBytes);
}
/* function to submit the batchListBytes to validator*/
async function sendTransaction(batchListBytes){
    let resp =await fetch('http://rest-api:8008/batches',{
        method: 'POST',
        headers: {'Content-Type' :'application/octet-stream'},
        body: batchListBytes
    })
       console.log("response" ,resp);         

}