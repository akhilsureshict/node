
function viewData() {
    window.location.href='/listView';

}

function getPropertyAddress(OwnerName,AadharNum){
    let keyHash =hash(getUserPublicKey(OwnerName))
    let nameHash =hash("Property Chain")
    let Aadhash =hash(AadharNum)
    return nameHash.slice(0,6) +Aadhash.slice(0,4)+keyHash.slice(0,60)
}
function addPropertyAsOwner(event) {
    event.preventDefault();
    let privKey =document.getElementById('ownPrivKey').value;
    let Aadharnumb =document.getElementById('ownad').value;
    let OwnNam =document.getElementById('OwnName').value;
    let LArea =document.getElementById('larea').value;
    let doa =document.getElementById('doa').value;
    let Addrs =document.getElementById('addr').value;
    let MobNumb =document.getElementById('mob').value;
    let NomNam  =document.getElementById('nomnam').value;
    let NomAad =document.getElementById('nomad').value;
    $.post('/addProperty',{key:privKey,ownerAadhar=Aadharnumb,owner:OwnNam,land:LArea,date:doa,address:Addrs,mobile:MobNumb,nominee:NomNam,nomineeAadhar:NomAad},'json')

 
}

function addPropertyAsRegister() {
    event.preventDefault();
    let privKey =document.getElementById('regPrivKey').value;
    let OwnNam =document.getElementById('ownname').value;
    let Aadno  =document.getElementById('ownAad').value;
    let adrs =document.getElementById('addrs').value;
    let dor =document.getElementById('DOR').value;
    let dist =document.getElementById('District').value;
    let sur =document.getElementById('survey').value;
    $.post('/registerProperty',{key:privKey,owner:OwnNam,Aadhar:Aadno,Address:adrs,Registrationdate:dor,district:dist,survey:sur},'json')
        
}